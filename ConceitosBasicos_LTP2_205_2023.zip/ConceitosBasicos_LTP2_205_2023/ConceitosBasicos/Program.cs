﻿    // See https://aka.ms/new-console-template for more information

Console.WriteLine("Hello, World!");
string nome = "Alex ";
string nome1 = "Cleitin";
string nome2 = "Gabe ";
Console.WriteLine("Seja bem-vindo " + nome);
string carro = "Kadett";
Console.WriteLine($"Eu gosto de {carro} ");

string sobrenome = "Rangel";
string sobrenome2 = "Cardoso";
Console.WriteLine($"Estes são {nome + sobrenome} e {nome2 + sobrenome2}");

int idade = 16;
Console.WriteLine("A idade é: "+ idade);

byte valor = 255;
valor += 1; // valor = valor + 1;
Console.WriteLine($"valor: {valor}");

decimal salario = 5000.20m;
Console.WriteLine(salario);

string nome3 = "Leticia e Vinicus";
Console.WriteLine("Ultimos românticos: "+ nome3);

Console.WriteLine($"{nome} e {nome1} juntos são tcp");

float altura = 1.76f;
double altura2 = altura * 0.000000001;
float peso = 83.2f; 
Console.WriteLine($"A altura é: {altura} m");
Console.WriteLine($"O peso é: {peso}kg");
Console.WriteLine($"Se vc pudesse ser o homem formiga, teria a altura {altura2}nm"); 